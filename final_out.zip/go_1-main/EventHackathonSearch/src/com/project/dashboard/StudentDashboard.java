package com.project.dashboard;

import com.project.models.Event;
import com.project.services.EventService;
import com.project.services.RegistrationService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class StudentDashboard extends JFrame {
    private EventService eventService = new EventService();
    private RegistrationService registrationService = new RegistrationService();
    private JTable inCampusEventTable;
    private JTable otherCollegeEventTable;
    private DefaultTableModel inCampusTableModel;
    private DefaultTableModel otherCollegeTableModel;
    private int studentId;
    private String studentCollege;

    public StudentDashboard(int studentId, String college) {
        this.studentId = studentId;
        this.studentCollege = college;

        setTitle("Student Dashboard");
        setSize(900, 600);
        setMinimumSize(new Dimension(800, 600));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // Header panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(34, 49, 63));
        JLabel headerLabel = new JLabel("Student Dashboard - Event Registration", SwingConstants.CENTER);
        headerLabel.setFont(new Font("SansSerif", Font.BOLD, 24));
        headerLabel.setForeground(new Color(255, 215, 0)); // Gold color
        headerPanel.add(headerLabel);

        // Main content panel with a GridLayout to remove spacing between panels
        JPanel contentPanel = new JPanel(new GridLayout(1, 2, 0, 0));

        // Initialize in-campus and other college event tables and models
        inCampusTableModel = new DefaultTableModel(new String[]{"ID", "Name", "Date", "Location"}, 0);
        otherCollegeTableModel = new DefaultTableModel(new String[]{"ID", "Name", "Date", "Location"}, 0);
        inCampusEventTable = new JTable(inCampusTableModel);
        otherCollegeEventTable = new JTable(otherCollegeTableModel);

        // In-campus events panel
        JPanel inCampusPanel = createEventPanel("In-Campus Events", inCampusEventTable);
        JPanel otherCollegePanel = createEventPanel("Other College Events", otherCollegeEventTable);

        // Buttons for registering and unregistering
        JPanel inCampusButtonPanel = createButtonPanel(inCampusEventTable, true);
        JPanel otherCollegeButtonPanel = createButtonPanel(otherCollegeEventTable, false);

        inCampusPanel.add(inCampusButtonPanel, BorderLayout.SOUTH);
        otherCollegePanel.add(otherCollegeButtonPanel, BorderLayout.SOUTH);

        // Add the panels to the content panel
        contentPanel.add(inCampusPanel);
        contentPanel.add(otherCollegePanel);

        // Add header and content panels to the main layout
        add(headerPanel, BorderLayout.NORTH);
        add(contentPanel, BorderLayout.CENTER);

        loadInCampusEvents();
        loadOtherCollegeEvents();
    }

    // Method to create and style event panel
    private JPanel createEventPanel(String title, JTable table) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder(title));
        panel.setBackground(new Color(44, 62, 80));
        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane, BorderLayout.CENTER);
        return panel;
    }

    // Method to create button panel for register/unregister
    private JPanel createButtonPanel(JTable table, boolean allowUnregister) {
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.setBackground(new Color(44, 62, 80));

        JButton registerButton = new JButton("Register");
        styleButton(registerButton, new Color(46, 204, 113), Color.BLACK);
        registerButton.addActionListener(new RegisterListener(table));
        buttonPanel.add(registerButton);

        if (allowUnregister) {
            JButton unregisterButton = new JButton("Unregister");
            styleButton(unregisterButton, new Color(231, 76, 60), Color.BLACK);
            unregisterButton.addActionListener(new UnregisterListener(table));
            buttonPanel.add(unregisterButton);
        }

        return buttonPanel;
    }

    private void styleButton(JButton button, Color bgColor, Color fgColor) {
        button.setBackground(bgColor);
        button.setForeground(fgColor);
        button.setFocusPainted(false);
        button.setFont(new Font("SansSerif", Font.BOLD, 14));
        button.setPreferredSize(new Dimension(120, 40));
    }

    // Load in-campus events specific to the student's college
    private void loadInCampusEvents() {
        inCampusTableModel.setRowCount(0); // Clear existing rows
        List<Event> events = eventService.getEventsByCollege(studentCollege);
        for (Event event : events) {
            inCampusTableModel.addRow(new Object[]{event.getId(), event.getName(), event.getDate(), event.getLocation()});
        }
    }

    // Load events from other colleges
    private void loadOtherCollegeEvents() {
        otherCollegeTableModel.setRowCount(0); // Clear existing rows
        List<Event> events = eventService.getAllEvents();
        for (Event event : events) {
            if (!event.getCollege().equals(studentCollege)) {
                otherCollegeTableModel.addRow(new Object[]{event.getId(), event.getName(), event.getDate(), event.getLocation()});
            }
        }
    }

    // Event listener for registering to an event
    private class RegisterListener implements ActionListener {
        private JTable targetTable;

        public RegisterListener(JTable targetTable) {
            this.targetTable = targetTable;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedRow = targetTable.getSelectedRow();
            if (selectedRow != -1) {
                int eventId = (int) targetTable.getValueAt(selectedRow, 0);

                // Check if already registered for the event
                if (registrationService.isAlreadyRegistered(studentId, eventId)) {
                    JOptionPane.showMessageDialog(StudentDashboard.this, "You are already registered for this event.");
                } else {
                    boolean success = registrationService.registerForEvent(studentId, eventId);
                    if (success) {
                        JOptionPane.showMessageDialog(StudentDashboard.this, "Registration request sent. Awaiting approval.");
                    } else {
                        JOptionPane.showMessageDialog(StudentDashboard.this, "Registration failed. Please try again.");
                    }
                }
            } else {
                JOptionPane.showMessageDialog(StudentDashboard.this, "Please select an event to register.");
            }
        }
    }

    // Event listener for unregistering from an event
    private class UnregisterListener implements ActionListener {
        private JTable targetTable;

        public UnregisterListener(JTable targetTable) {
            this.targetTable = targetTable;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedRow = targetTable.getSelectedRow();
            if (selectedRow != -1) {
                int eventId = (int) targetTable.getValueAt(selectedRow, 0);
                boolean success = registrationService.unregisterFromEvent(studentId, eventId);
                if (success) {
                    JOptionPane.showMessageDialog(StudentDashboard.this, "Successfully unregistered from the event.");
                } else {
                    JOptionPane.showMessageDialog(StudentDashboard.this, "Unregistration failed.");
                }
            } else {
                JOptionPane.showMessageDialog(StudentDashboard.this, "Please select an event to unregister.");
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new StudentDashboard(2, "Rajalakshmi Engineering College").setVisible(true)); // Example student ID and college
    }
}
