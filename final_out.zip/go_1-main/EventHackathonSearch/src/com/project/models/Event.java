package com.project.models;

import java.util.Date;

public class Event {
    private int id;
    private String name;
    private String description;
    private Date date;
    private String location;
    private String college;
    private int createdBy;
    private String posterPath;
    private String approvalStatus; // New field for registration status

    // Full Constructor with approvalStatus
    public Event(int id, String name, String description, Date date, String location, String college, int createdBy, String posterPath, String approvalStatus) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.date = date;
        this.location = location;
        this.college = college;
        this.createdBy = createdBy;
        this.posterPath = posterPath;
        this.approvalStatus = approvalStatus;
    }

    // Original Constructor without approvalStatus (for other uses)
    public Event(int id, String name, String description, Date date, String location, String college, int createdBy, String posterPath) {
        this(id, name, description, date, location, college, createdBy, posterPath, null);
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getCollege() {
        return college;
    }

    public void setCollege(String college) {
        this.college = college;
    }

    public int getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(int createdBy) {
        this.createdBy = createdBy;
    }

    public String getPosterPath() {
        return posterPath;
    }

    public void setPosterPath(String posterPath) {
        this.posterPath = posterPath;
    }

    public String getApprovalStatus() {
        return approvalStatus;
    }

    public void setApprovalStatus(String approvalStatus) {
        this.approvalStatus = approvalStatus;
    }
}
