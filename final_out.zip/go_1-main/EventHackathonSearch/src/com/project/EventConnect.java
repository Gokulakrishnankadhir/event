package com.project;

import com.project.auth.LoginPage;
import java.awt.*;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.*;

public class EventConnect {

    public static void main(String[] args) {
        // Show the enhanced splash screen
        SplashScreen splash = new SplashScreen();
        splash.setVisible(true);

        // Set timer for 3 seconds to display splash screen, then open LoginPage
        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {
                splash.dispose(); // Close the splash screen
                SwingUtilities.invokeLater(() -> new LoginPage().setVisible(true)); // Open LoginPage
            }
        }, 4000); // 3000 ms = 3 seconds
    }
}

class SplashScreen extends JFrame {
    private JProgressBar progressBar;

    public SplashScreen() {
        setTitle("Welcome to EventConnect");
        setSize(600, 400);
        setLocationRelativeTo(null); // Center the window
        setUndecorated(true); // Remove title bar for a cleaner look

        // Create and customize the main panel for splash screen content
        JPanel panel = new JPanel();
        panel.setBackground(new Color(44, 62, 80));
        panel.setLayout(new BorderLayout());
        panel.setBorder(BorderFactory.createLineBorder(new Color(46, 204, 113), 3, true)); // Add rounded border

         
        // Top panel for the logo
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(new Color(44, 62, 80));
        JLabel logoLabel = new JLabel(new ImageIcon("resources/images/logo.png")); // Placeholder for logo
        logoLabel.setHorizontalAlignment(SwingConstants.CENTER);
        topPanel.add(logoLabel, BorderLayout.CENTER);

    
        JLabel titleLabel = new JLabel("EventConnect", SwingConstants.CENTER);
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 32));
        titleLabel.setForeground(new Color(255, 223, 0)); // Gold color for title text


        JLabel subTitleLabel = new JLabel("Connecting You to Opportunities", SwingConstants.CENTER);
        subTitleLabel.setFont(new Font("SansSerif", Font.ITALIC, 18));
        subTitleLabel.setForeground(new Color(189, 195, 199));
        subTitleLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 20, 0));

        // Loading message and progress bar
        JLabel loadingLabel = new JLabel("Loading, please wait...", SwingConstants.CENTER);
        loadingLabel.setFont(new Font("SansSerif", Font.PLAIN, 14));
        loadingLabel.setForeground(new Color(189, 195, 199));

        progressBar = new JProgressBar();
        progressBar.setIndeterminate(true); // Shows an indeterminate progress bar
        progressBar.setBackground(new Color(52, 73, 94));
        progressBar.setForeground(new Color(39, 174, 96)); // Bright green for progress bar
        progressBar.setPreferredSize(new Dimension(580, 20));

        // Add components to panel
        panel.add(topPanel, BorderLayout.NORTH);
        panel.add(titleLabel, BorderLayout.CENTER);
        panel.add(subTitleLabel, BorderLayout.SOUTH);

        // Bottom panel for progress bar and loading text
        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(new Color(44, 62, 80));
        bottomPanel.setLayout(new BorderLayout());
        bottomPanel.add(loadingLabel, BorderLayout.NORTH);
        bottomPanel.add(progressBar, BorderLayout.SOUTH);

        // Add all panels to the main panel
        panel.add(topPanel, BorderLayout.NORTH);
        panel.add(titleLabel, BorderLayout.CENTER);
        panel.add(subTitleLabel, BorderLayout.CENTER);
        panel.add(bottomPanel, BorderLayout.SOUTH);

        add(panel); // Add panel to the frame
    }
}
